"""Hunter Bot — Signal / Decision Model"""
from dataclasses import dataclass, field
from typing import Optional, List, Dict
from datetime import datetime, timezone
from enum import Enum


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


class HunterDecision(Enum):
    HUNT_NOW = "HUNT_NOW"
    WATCH = "WATCH"
    IGNORE = "IGNORE"


@dataclass
class HunterSignal:
    ticker: str
    decision: HunterDecision
    hunter_score: int = 0
    data_confidence: int = 0
    timestamp: datetime = field(default_factory=_utc_now)

    news_quality: int = 0
    news_impact: int = 0
    market_reaction: int = 0
    liquidity_proxy: int = 0
    technical_structure: int = 0
    momentum: int = 0

    catalyst_type: str = ""
    sentiment: str = "NEUTRAL"
    session: str = ""
    current_price: Optional[float] = None
    change_percent: Optional[float] = None
    rvol: Optional[float] = None
    technical_setup: str = "NO_SETUP"
    liquidity_status: str = "UNKNOWN"
    reaction_status: str = "UNKNOWN"

    warnings: List[str] = field(default_factory=list)
    reasoning: str = ""
    data_insufficient_note: Optional[str] = None

    @property
    def is_actionable(self) -> bool:
        return self.decision == HunterDecision.HUNT_NOW and self.data_confidence >= 60

    def to_dict(self) -> Dict:
        return {
            "ticker": self.ticker,
            "decision": self.decision.value,
            "hunter_score": self.hunter_score,
            "data_confidence": self.data_confidence,
            "components": {
                "news_quality": self.news_quality,
                "news_impact": self.news_impact,
                "market_reaction": self.market_reaction,
                "liquidity_proxy": self.liquidity_proxy,
                "technical_structure": self.technical_structure,
                "momentum": self.momentum,
            },
            "context": {
                "price": self.current_price,
                "change_pct": self.change_percent,
                "rvol": self.rvol,
                "setup": self.technical_setup,
                "liquidity": self.liquidity_status,
                "reaction": self.reaction_status,
                "session": self.session,
            },
            "warnings": self.warnings,
            "reasoning": self.reasoning,
        }
