"""Hunter Bot — Telegram Notifier"""
from telegram import Bot
from models.signal import HunterSignal, HunterDecision
from utils.logger import LOGGER


class TelegramNotifier:
    def __init__(self, bot_token: str, chat_id: str):
        self.bot = Bot(token=bot_token)
        self.chat_id = chat_id

    async def send_signal(self, signal: HunterSignal):
        emoji_map = {
            HunterDecision.HUNT_NOW: "🚀",
            HunterDecision.WATCH: "👀",
            HunterDecision.IGNORE: "❌",
        }

        sentiment_emoji = {
            "VERY_POSITIVE": "🟢",
            "POSITIVE": "🟢",
            "NEUTRAL": "🟡",
            "NEGATIVE": "🔴",
            "VERY_NEGATIVE": "🔴",
        }

        lines = [
            f"🚨 <b>HUNTER NEWS RADAR</b>",
            f"",
            f"<b>${signal.ticker}</b>",
            f"",
            f"📰 <b>CATALYST</b>",
            f"{signal.catalyst_type}",
            f"",
            f"{sentiment_emoji.get(signal.sentiment, '🟡')} <b>SENTIMENT</b>",
            f"{signal.sentiment.replace('_', ' ')}",
            f"",
            f"🔥 <b>NEWS IMPACT</b>",
            f"{signal.news_impact}/100",
            f"",
            f"🧠 <b>NEWS QUALITY</b>",
            f"{signal.news_quality}/100",
            f"",
            f"📈 <b>MARKET REACTION</b>",
            f"{signal.reaction_status.replace('_', ' ')}",
            f"",
            f"💰 <b>LIQUIDITY PROXY</b>",
            f"{signal.liquidity_status.replace('_', ' ')}",
            f"",
            f"📊 <b>RVOL</b>",
            f"{signal.rvol}x" if signal.rvol else "N/A",
            f"",
            f"📈 <b>CHANGE</b>",
            f"{signal.change_percent:+.2f}%" if signal.change_percent else "N/A",
            f"",
            f"📍 <b>SESSION</b>",
            f"{signal.session}",
            f"",
            f"📊 <b>TECHNICAL</b>",
            f"{signal.technical_setup.replace('_', ' ')}",
            f"",
            f"🔥 <b>HUNTER SCORE</b>",
            f"{signal.hunter_score}/100",
            f"",
            f"{emoji_map.get(signal.decision, '⚪')} <b>DECISION</b>",
            f"{signal.decision.value.replace('_', ' ')}",
            f"",
            f"📊 <b>DATA CONFIDENCE</b>",
            f"{signal.data_confidence}%",
            f"",
            f"💡 <b>REASON</b>",
            f"{signal.reasoning}",
        ]

        if signal.warnings:
            lines.extend([f"", f"⚠️ <b>WARNINGS</b>"])
            for w in signal.warnings:
                lines.append(f"• {w.replace('_', ' ')}")

        if signal.data_insufficient_note:
            lines.extend([f"", f"⚠️ <b>DATA NOTE</b>", f"{signal.data_insufficient_note}"])

        lines.extend([f"", f"─" * 20, f"<i>Fewer Alerts → Higher Quality</i>"])

        text = "\n".join(lines)

        try:
            await self.bot.send_message(
                chat_id=self.chat_id,
                text=text,
                parse_mode="HTML",
                disable_web_page_preview=True,
            )
            LOGGER.info(f"[Telegram] Sent alert for {signal.ticker}")
        except Exception as e:
            LOGGER.error(f"[Telegram] Failed to send: {e}")
