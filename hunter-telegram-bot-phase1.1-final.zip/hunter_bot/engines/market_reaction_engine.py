"""Hunter Bot — Market Reaction Engine.

Phase 1 uses real intraday candles when available. It never fabricates a
"before news" price or volume from a session total. If the required windows
are unavailable the reaction is DATA_INSUFFICIENT.
"""
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Optional, Tuple

import pandas as pd

from models.ticker import TickerData
from models.news import CatalystEvent
from core.session_clock import SessionClock, MarketSession
from utils.logger import LOGGER


@dataclass
class ReactionMetrics:
    price_before: Optional[float] = None
    price_after: Optional[float] = None
    price_after_5m: Optional[float] = None
    price_after_15m: Optional[float] = None
    price_after_30m: Optional[float] = None
    price_change_pct: Optional[float] = None
    volume_before: Optional[int] = None
    volume_after: Optional[int] = None
    volume_after_5m: Optional[int] = None
    volume_after_15m: Optional[int] = None
    volume_after_30m: Optional[int] = None
    rvol: Optional[float] = None
    gap_pct: Optional[float] = None
    vwap_at_news: Optional[float] = None
    price_vs_vwap_pct: Optional[float] = None
    reaction_label: str = "UNKNOWN"
    reaction_score: int = 0
    data_sufficient: bool = False


class MarketReactionEngine:
    """Measure actual price/volume reaction around the news timestamp."""

    def analyze(self, event: CatalystEvent, ticker_data: TickerData) -> ReactionMetrics:
        metrics = ReactionMetrics()

        if not ticker_data.is_data_sufficient:
            metrics.reaction_label = "DATA_INSUFFICIENT"
            return metrics

        news_time = event.primary_source.published_at
        if not news_time:
            metrics.reaction_label = "DATA_INSUFFICIENT"
            return metrics

        bars = self._normalize_bars(ticker_data.intraday_bars)
        if bars.empty:
            metrics.reaction_label = "DATA_INSUFFICIENT"
            return metrics

        news_et = SessionClock.localize(news_time)
        session = SessionClock.get_session(news_et)
        if session == MarketSession.CLOSED:
            metrics.reaction_label = "DATA_INSUFFICIENT"
            return metrics

        # Baseline: last completed candle in the 15 minutes immediately before
        # the news. This is deliberately NOT previous_close/session_total.
        before = self._window(bars, news_et - timedelta(minutes=15), news_et)
        if before.empty:
            metrics.reaction_label = "DATA_INSUFFICIENT"
            return metrics

        baseline_row = before.iloc[-1]
        metrics.price_before = float(baseline_row["Close"])
        metrics.volume_before = int(before["Volume"].sum()) if "Volume" in before else None

        metrics.price_after_5m, metrics.volume_after_5m = self._point_and_volume(bars, news_et + timedelta(minutes=5))
        metrics.price_after_15m, metrics.volume_after_15m = self._point_and_volume(bars, news_et + timedelta(minutes=15))
        metrics.price_after_30m, metrics.volume_after_30m = self._point_and_volume(bars, news_et + timedelta(minutes=30))

        # Prefer +15m for the canonical reaction. Fall back to +5m only when
        # +15m is unavailable but +5m exists. No fallback to current session price.
        if metrics.price_after_15m is not None:
            metrics.price_after = metrics.price_after_15m
            metrics.volume_after = metrics.volume_after_15m
        elif metrics.price_after_5m is not None:
            metrics.price_after = metrics.price_after_5m
            metrics.volume_after = metrics.volume_after_5m
        else:
            metrics.reaction_label = "DATA_INSUFFICIENT"
            return metrics

        if metrics.price_before > 0:
            metrics.price_change_pct = round(
                ((metrics.price_after - metrics.price_before) / metrics.price_before) * 100,
                2,
            )

        metrics.rvol = ticker_data.relative_volume
        metrics.gap_pct = ticker_data.gap_percent

        vwap = self._vwap_at_or_before(bars, news_et)
        if vwap is not None and metrics.price_after is not None:
            metrics.vwap_at_news = round(vwap, 4)
            metrics.price_vs_vwap_pct = round(
                ((metrics.price_after - vwap) / vwap) * 100, 2
            )

        metrics.data_sufficient = True
        metrics.reaction_score = self._calculate_score(metrics, session)
        metrics.reaction_label = self._label_score(metrics.reaction_score)

        event.price_before = metrics.price_before
        event.price_after = metrics.price_after
        event.volume_before = metrics.volume_before
        event.volume_after = metrics.volume_after

        LOGGER.info(
            f"[Reaction] {ticker_data.ticker} | {metrics.reaction_label} | "
            f"Before: {metrics.price_before} | +5m: {metrics.price_after_5m} | "
            f"+15m: {metrics.price_after_15m} | +30m: {metrics.price_after_30m}"
        )
        return metrics

    @staticmethod
    def _normalize_bars(bars) -> pd.DataFrame:
        if bars is None:
            return pd.DataFrame()
        try:
            df = bars.copy()
        except AttributeError:
            return pd.DataFrame()
        if df.empty or "Close" not in df.columns:
            return pd.DataFrame()

        if not isinstance(df.index, pd.DatetimeIndex):
            if "timestamp" in df.columns:
                df = df.set_index("timestamp")
            else:
                return pd.DataFrame()

        idx = pd.to_datetime(df.index, utc=True).tz_convert("America/New_York")
        df.index = idx
        df = df.sort_index()
        if "Volume" not in df.columns:
            df["Volume"] = 0
        return df

    @staticmethod
    def _window(df: pd.DataFrame, start: datetime, end: datetime) -> pd.DataFrame:
        start_et = SessionClock.localize(start)
        end_et = SessionClock.localize(end)
        return df[(df.index >= start_et) & (df.index < end_et)]

    def _point_and_volume(self, df: pd.DataFrame, target: datetime) -> Tuple[Optional[float], Optional[int]]:
        target_et = SessionClock.localize(target)
        # Allow a small tolerance around the requested point; never use a bar
        # from the future beyond 2 minutes.
        window = df[(df.index >= target_et) & (df.index <= target_et + timedelta(minutes=2))]
        if window.empty:
            return None, None
        row = window.iloc[0]
        return float(row["Close"]), int(row["Volume"])

    def _vwap_at_or_before(self, df: pd.DataFrame, target: datetime) -> Optional[float]:
        target_et = SessionClock.localize(target)
        window = df[df.index <= target_et]
        if window.empty:
            return None
        if window["Volume"].sum() <= 0:
            return None
        typical = (window["High"] + window["Low"] + window["Close"]) / 3
        return float((typical * window["Volume"]).sum() / window["Volume"].sum())

    def _calculate_score(self, m: ReactionMetrics, session: MarketSession) -> int:
        score = 50
        change = m.price_change_pct or 0
        if change > 15:
            score += 30
        elif change > 8:
            score += 20
        elif change > 3:
            score += 10
        elif change < -5:
            score -= 30
        elif change < -2:
            score -= 15

        rvol = m.rvol or 1.0
        if rvol >= 5:
            score += 20
        elif rvol >= 3:
            score += 15
        elif rvol >= 2:
            score += 8
        elif rvol < 1.2:
            score -= 15

        if m.volume_before is not None and m.volume_after is not None:
            if m.volume_after > m.volume_before:
                score += 5
            elif m.volume_after < max(1, int(m.volume_before * 0.5)):
                score -= 5

        vwap_dist = m.price_vs_vwap_pct
        if vwap_dist is not None:
            if vwap_dist > 5:
                score += 10
            elif vwap_dist < -3:
                score -= 10

        if session == MarketSession.PREMARKET and change > 5:
            score += 5

        return max(0, min(100, score))

    @staticmethod
    def _label_score(score: int) -> str:
        if score >= 80:
            return "STRONG_POSITIVE_REACTION"
        if score >= 60:
            return "POSITIVE_REACTION"
        if score >= 40:
            return "WEAK_REACTION"
        if score >= 20:
            return "NEUTRAL"
        return "NEGATIVE_REACTION"
