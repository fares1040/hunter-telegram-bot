"""Hunter Bot — Decision Engine (Phase 1)"""
from typing import Optional

from models.ticker import TickerData
from models.news import CatalystEvent
from models.signal import HunterSignal, HunterDecision
from engines.market_reaction_engine import ReactionMetrics
from engines.liquidity_proxy import LiquidityProxyResult
from engines.technical_engine import TechnicalProfile
from core.data_confidence import DataConfidenceReport
from core.session_clock import SessionClock
from config.settings import SETTINGS
from utils.logger import LOGGER


class DecisionEngine:
    def decide(
        self,
        ticker_data: TickerData,
        event: CatalystEvent,
        reaction: ReactionMetrics,
        liquidity: LiquidityProxyResult,
        technical: TechnicalProfile,
        confidence_report: DataConfidenceReport,
    ) -> HunterSignal:

        signal = HunterSignal(ticker=ticker_data.ticker, decision=HunterDecision.IGNORE)
        signal.data_confidence = confidence_report.score
        signal.session = SessionClock.get_session(ticker_data.timestamp).value
        signal.current_price = ticker_data.current_price
        signal.change_percent = ticker_data.change_percent
        signal.rvol = ticker_data.relative_volume
        signal.catalyst_type = event.catalyst_type.value
        signal.sentiment = event.sentiment

        signal.news_quality = event.source_tier_score
        signal.news_impact = event.impact_score
        signal.market_reaction = reaction.reaction_score
        signal.liquidity_proxy = liquidity.score
        signal.technical_structure = technical.setup_score

        momentum = reaction.reaction_score * 0.4 + liquidity.score * 0.3
        if ticker_data.change_percent and ticker_data.change_percent > 5:
            momentum += 10
        signal.momentum = min(100, int(momentum))

        weights = {
            "news_quality": 0.15,
            "news_impact": 0.20,
            "market_reaction": 0.25,
            "liquidity_proxy": 0.15,
            "technical_structure": 0.15,
            "momentum": 0.10,
        }

        signal.hunter_score = int(
            signal.news_quality * weights["news_quality"] +
            signal.news_impact * weights["news_impact"] +
            signal.market_reaction * weights["market_reaction"] +
            signal.liquidity_proxy * weights["liquidity_proxy"] +
            signal.technical_structure * weights["technical_structure"] +
            signal.momentum * weights["momentum"]
        )

        signal.technical_setup = technical.setup
        signal.liquidity_status = liquidity.status
        signal.reaction_status = reaction.reaction_label
        signal.warnings = list(technical.warnings)

        if signal.data_confidence < SETTINGS.hunter_min_data_confidence:
            signal.decision = HunterDecision.IGNORE
            signal.reasoning = (
                f"Data confidence too low ({signal.data_confidence}%). "
                f"Missing: {confidence_report.missing_fields}"
            )
            signal.data_insufficient_note = f"Confidence {signal.data_confidence}% < threshold {SETTINGS.hunter_min_data_confidence}%"
            LOGGER.info(f"[Decision] {ticker_data.ticker} IGNORED — low data confidence")
            return signal

        if event.sentiment in ["NEGATIVE", "VERY_NEGATIVE"]:
            signal.decision = HunterDecision.IGNORE
            signal.reasoning = "Negative sentiment"
            return signal

        if event.priced_in_probability > 0.7:
            signal.decision = HunterDecision.IGNORE
            signal.reasoning = f"Likely priced in ({event.priced_in_probability:.0%})"
            return signal

        if reaction.reaction_label == "NEGATIVE_REACTION":
            signal.decision = HunterDecision.IGNORE
            signal.reasoning = "Market reacted negatively to news"
            return signal

        if liquidity.status == "WEAK":
            signal.decision = HunterDecision.IGNORE
            signal.reasoning = "Liquidity proxy too weak"
            return signal

        if technical.setup == "NO_SETUP" and reaction.reaction_score < 60:
            signal.decision = HunterDecision.IGNORE
            signal.reasoning = "No technical setup and weak reaction"
            return signal

        hunt_conditions = [
            signal.hunter_score >= SETTINGS.hunter_min_score,
            event.impact_score >= 70,
            reaction.reaction_score >= 60,
            liquidity.score >= 60,
            technical.setup_score >= 60,
            event.is_fresh(max_age_minutes=120),
        ]

        if all(hunt_conditions):
            signal.decision = HunterDecision.HUNT_NOW
            signal.reasoning = (
                f"Strong catalyst ({event.catalyst_type.value}) + "
                f"positive reaction ({reaction.reaction_label}) + "
                f"liquidity ({liquidity.status}) + "
                f"technical ({technical.setup})"
            )
            LOGGER.info(f"[Decision] {ticker_data.ticker} HUNT_NOW — Score: {signal.hunter_score}")
            return signal

        if not event.is_fresh(max_age_minutes=120):
            signal.decision = HunterDecision.IGNORE
            signal.reasoning = "News is stale (>2 hours old)"
            LOGGER.info(f"[Decision] {ticker_data.ticker} IGNORE — stale news")
            return signal

        watch_conditions = [
            event.impact_score >= 60,
            event.sentiment in ["POSITIVE", "VERY_POSITIVE"],
            not all(hunt_conditions),
        ]

        if all(watch_conditions):
            signal.decision = HunterDecision.WATCH
            reasons = []
            if signal.hunter_score < SETTINGS.hunter_min_score:
                reasons.append(f"score {signal.hunter_score} < {SETTINGS.hunter_min_score}")
            if reaction.reaction_score < 60:
                reasons.append("reaction weak")
            if liquidity.score < 60:
                reasons.append("liquidity unconfirmed")
            if technical.setup_score < 60:
                reasons.append(f"setup {technical.setup}")
            if not event.is_fresh(max_age_minutes=120):
                reasons.append("stale")

            signal.reasoning = f"Strong news but: {', '.join(reasons)}"
            LOGGER.info(f"[Decision] {ticker_data.ticker} WATCH — Score: {signal.hunter_score}")
            return signal

        signal.decision = HunterDecision.IGNORE
        signal.reasoning = "Did not meet HUNT_NOW or WATCH criteria"
        LOGGER.info(f"[Decision] {ticker_data.ticker} IGNORE — Score: {signal.hunter_score}")
        return signal
