"""Hunter Bot — Centralized Configuration"""
import os
from typing import Optional
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field, field_validator


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        populate_by_name=True,
    )

    telegram_bot_token: str = Field(..., alias="TELEGRAM_BOT_TOKEN")
    telegram_chat_id: str = Field(..., alias="TELEGRAM_CHAT_ID")

    openai_api_key: str = Field(..., alias="OPENAI_API_KEY")
    openai_model: str = Field(default="gpt-4o-mini", alias="OPENAI_MODEL")

    polygon_api_key: Optional[str] = Field(default=None, alias="POLYGON_API_KEY")
    finnhub_api_key: Optional[str] = Field(default=None, alias="FINNHUB_API_KEY")

    hunter_min_score: int = Field(default=70, ge=0, le=100, alias="HUNTER_MIN_SCORE")
    hunter_min_data_confidence: int = Field(
        default=60, ge=0, le=100, alias="HUNTER_MIN_DATA_CONFIDENCE"
    )

    market_timezone: str = Field(default="America/New_York", alias="MARKET_TIMEZONE")
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")

    max_watchlist_price: float = 100.0
    min_relative_volume: float = 2.0
    min_dollar_volume: float = 1_000_000.0
    max_gap_percent: float = 50.0

    @field_validator("log_level")
    @classmethod
    def validate_log_level(cls, v: str) -> str:
        allowed = {"DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"}
        if v.upper() not in allowed:
            raise ValueError(f"LOG_LEVEL must be one of {allowed}")
        return v.upper()

    @property
    def has_polygon(self) -> bool:
        return bool(self.polygon_api_key and self.polygon_api_key.strip())

    @property
    def has_finnhub(self) -> bool:
        return bool(self.finnhub_api_key and self.finnhub_api_key.strip())


# Create instance — will load from .env if present
# If .env is missing, this will fail at import time (expected behavior)
try:
    SETTINGS = Settings()
except Exception:
    # Fallback for testing without .env
    SETTINGS = Settings(
        telegram_bot_token="test",
        telegram_chat_id="test",
        openai_api_key="",
        openai_model="gpt-4o-mini",
    )
