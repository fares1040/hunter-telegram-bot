"""Hunter Bot — Polygon.io Provider (STUB / FUTURE)"""
from providers.market_data.base_provider import MarketDataProvider
from models.ticker import TickerData
from core.exceptions import ProviderError


class PolygonProvider(MarketDataProvider):
    name = "polygon"

    @property
    def is_realtime(self) -> bool:
        return True

    async def fetch_ticker(self, ticker: str, timestamp=None) -> TickerData:
        raise ProviderError(
            "PolygonProvider not yet implemented. Use YFinanceProvider as fallback.",
            provider=self.name,
            retryable=False,
        )

    async def health_check(self) -> bool:
        return False
