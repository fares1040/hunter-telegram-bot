"""Hunter Bot — Main Orchestrator"""
import asyncio
import pandas as pd
from datetime import datetime
from typing import List, Optional

from config.settings import SETTINGS
from core.session_clock import SessionClock
from core.data_confidence import DataConfidenceReport, DataQuality
from core.exceptions import ProviderError, DataInsufficientError
from utils.logger import LOGGER

from providers.market_data.yfinance_provider import YFinanceProvider
from providers.market_data.base_provider import MarketDataProvider
from providers.news.finnhub_provider import FinnhubNewsProvider
from providers.news.base_provider import NewsProvider

from engines.news_engine import NewsEngine
from engines.market_reaction_engine import MarketReactionEngine
from engines.liquidity_proxy import LiquidityProxyEngine
from engines.technical_engine import TechnicalEngine
from engines.decision_engine import DecisionEngine

from ai.analyzer import AIAnalyzer
from bot.telegram_bot import TelegramNotifier

from models.ticker import TickerData
from models.news import CatalystEvent
from models.signal import HunterSignal


class HunterOrchestrator:
    def __init__(self):
        self.market_provider: MarketDataProvider = YFinanceProvider()
        self.news_providers: List[NewsProvider] = []
        if SETTINGS.has_finnhub:
            self.news_providers.append(FinnhubNewsProvider())

        self.news_engine = NewsEngine(self.news_providers)
        self.reaction_engine = MarketReactionEngine()
        self.liquidity_engine = LiquidityProxyEngine()
        self.technical_engine = TechnicalEngine()
        self.decision_engine = DecisionEngine()
        self.ai_analyzer = AIAnalyzer()

        self.notifier = TelegramNotifier(
            SETTINGS.telegram_bot_token,
            SETTINGS.telegram_chat_id,
        )

    async def process_ticker(self, ticker: str) -> HunterSignal:
        LOGGER.info(f"{'='*40}")
        LOGGER.info(f"[Pipeline] Starting analysis for {ticker}")
        LOGGER.info(f"{'='*40}")

        try:
            ticker_data = await self.market_provider.fetch_ticker(ticker)
        except (ProviderError, DataInsufficientError) as e:
            LOGGER.error(f"[Pipeline] Market data failed for {ticker}: {e}")
            return self._error_signal(ticker, f"Market data error: {e}")

        if not ticker_data.is_data_sufficient:
            return self._error_signal(ticker, "Insufficient market data")

        history_3mo = await self._fetch_history(ticker)

        raw_news = await self.news_engine.gather_news(ticker, max_age_hours=24)
        if not raw_news:
            LOGGER.info(f"[Pipeline] No news for {ticker}")
            return self._ignore_signal(ticker, "No recent news")

        events = self.news_engine.cluster_events(raw_news)
        events = self.news_engine.filter_material_events(events)
        if not events:
            return self._ignore_signal(ticker, "No material events after filtering")

        primary_event = events[0]
        primary_event = await self.ai_analyzer.analyze_event(primary_event)

        reaction = self.reaction_engine.analyze(primary_event, ticker_data)
        liquidity = self.liquidity_engine.analyze(ticker_data)
        technical = self.technical_engine.analyze(ticker_data, history_3mo)
        confidence = self._build_confidence(ticker_data, primary_event, reaction, liquidity, technical)

        signal = self.decision_engine.decide(
            ticker_data, primary_event, reaction, liquidity, technical, confidence
        )

        if signal.decision.value in ["HUNT_NOW", "WATCH"]:
            try:
                await self.notifier.send_signal(signal)
            except Exception as e:
                LOGGER.error(f"[Pipeline] Telegram failed: {e}")

        return signal

    async def _fetch_history(self, ticker: str) -> Optional[pd.DataFrame]:
        try:
            import yfinance as yf
            stock = yf.Ticker(ticker)
            return stock.history(period="3mo", interval="1d")
        except Exception as e:
            LOGGER.warning(f"[History] Failed for {ticker}: {e}")
            return None

    def _build_confidence(
        self,
        data: TickerData,
        event: CatalystEvent,
        reaction,
        liquidity,
        technical,
    ) -> DataConfidenceReport:
        report = DataConfidenceReport(ticker=data.ticker)

        report.add("current_price", DataQuality.REAL if data.provider_name != "unknown" else DataQuality.PROXY, 2.0)
        report.add("previous_close", DataQuality.REAL if data.previous_close else DataQuality.MISSING, 1.5)

        pre_quality = DataQuality.REAL if data.premarket.is_complete else DataQuality.MISSING
        report.add("premarket_data", pre_quality, 1.5)

        reg_quality = DataQuality.REAL if data.regular.is_complete else DataQuality.MISSING
        report.add("regular_session_data", reg_quality, 1.5)

        report.add("news_timestamp", DataQuality.REAL if event.primary_source.published_at else DataQuality.MISSING, 1.0)
        report.add("news_source_tier", DataQuality.REAL, 1.0)

        report.add("rvol", DataQuality.PROXY if data.relative_volume else DataQuality.MISSING, 1.0)
        report.add("technical_indicators", DataQuality.PROXY if technical.ma20 else DataQuality.MISSING, 1.0)

        for name, quality, weight in liquidity.data_quality_notes:
            report.add(f"liquidity_{name}", quality, weight)

        LOGGER.info(f"[Confidence] {report.summary()}")
        return report

    def _error_signal(self, ticker: str, reason: str) -> HunterSignal:
        return HunterSignal(
            ticker=ticker,
            decision=HunterDecision.IGNORE,
            hunter_score=0,
            data_confidence=0,
            reasoning=reason,
            data_insufficient_note=reason,
        )

    def _ignore_signal(self, ticker: str, reason: str) -> HunterSignal:
        return HunterSignal(
            ticker=ticker,
            decision=HunterDecision.IGNORE,
            hunter_score=0,
            data_confidence=50,
            reasoning=reason,
        )


async def main():
    orchestrator = HunterOrchestrator()
    test_tickers = ["AAPL", "NVDA", "TSLA"]
    for ticker in test_tickers:
        await orchestrator.process_ticker(ticker)
        await asyncio.sleep(2)


if __name__ == "__main__":
    asyncio.run(main())
