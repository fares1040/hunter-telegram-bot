# Hunter Telegram Bot — Phase 1.1

AI-assisted, news-driven stock opportunity radar focused on **HUNT_NOW / WATCH / IGNORE** decisions.

## Phase 1 scope

- News catalyst collection and clustering
- Source quality tiers: Official > Major > Financial > Unverified
- AI sentiment / materiality analysis
- Session-aware market data: Premarket / Regular / After-Hours
- Real intraday-candle market reaction when candles around the news timestamp are available
- Liquidity **proxy** using RVOL + dollar volume (no fake money-flow claims)
- Technical structure scoring
- Data-confidence gating
- Telegram alerts with no entry/stop/target recommendations
- Synthetic integration tests with no external API calls

## Important data rule

`MarketReactionEngine` does not invent a before-news price or volume. It requires intraday candles around the news timestamp. Missing reaction windows produce `DATA_INSUFFICIENT`.

## Run locally

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
pytest -q
python run.py
```

Do not commit `.env` or API keys.

## Phase 1 status

Verified locally with the included synthetic test suite:

**28 passed, 0 failed**

This is still a Phase 1 foundation. Real-time market data, options flow, persistent storage, backtesting, and entry/stop/target logic belong to later phases.


## Phase 1.1 verification notes

The uploaded Phase 1 package was independently inspected and its local synthetic test suite was executed.
Phase 1.1 also includes an anchor-safety correction so historical/event analysis cannot accidentally include
future candles in Premarket/Regular/After-Hours snapshots. Decision session labeling now follows the ticker
analysis timestamp rather than the machine's current wall clock.

This package contains no real `.env`, API keys, virtual environment, or Python bytecode.
